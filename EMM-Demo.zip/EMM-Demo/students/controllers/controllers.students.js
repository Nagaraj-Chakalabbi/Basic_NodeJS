var app = require('../../config/config.express');
var Student = require('../models/models.student');
var Course = require('../models/models.courses');

app.post('/', function(req, res, next) {
    var student = new Student(req.body);
    student.save(function(err) {
        if (err) {
            return next(err);
        } else {
            res.json(student);
        }
    });
});

app.post('/course', function(req, res, next) {
    var course = new Course(req.body);
    Course.insertMany(req.body, function(err, data) {
        if (err) {
            return next(err);
        } else {
            res.json(data);
        }
    });
});

app.post('/find_course', function(req, res, next) {
    var courseName = req.body.courseName;
    Course.find({ "courseName": { $regex: courseName, $options: 'i' } }, function(err, data) {
        if (err) {
            return next(err);
        } else {
            res.json(data);
        }
    });
});

app.post('/update_course', function(req, res, next) {
    var courseCode = req.body.courseCode;
    var pubYear = req.body.pubYear;
    Course.updateOne({ "courseCode": courseCode }, { "pubYear": pubYear }, function(err, data) {
        if (err) {
            return next(err);
        } else {
            res.json(data);
        }
    });
});

app.post('/delete_course', function(req, res, next) {
    var courseCode = req.body.courseCode;
    Course.deleteMany({ "courseCode": courseCode }, function(err, data) {
        if (err) {
            return next(err);
        } else {
            res.json(data);
        }
    });
});