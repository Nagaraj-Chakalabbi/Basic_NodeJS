var express = require('express');

var app = new express();

app.use('/', (req, res) => {
    res.send('Welcome Student');
}).listen(3000);