var app = require('./config/config.express');

app.use('/', (req, res) => {
    res.send('Welcome to ExpressJS');
});