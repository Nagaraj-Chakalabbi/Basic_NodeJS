var express = require('express');
var bodyParser = require('body-parser');
require("dotenv").config();
var mongoose = require('./config.mongoose');
var passport = require("passport")
var LocalStrategy = require("passport-local");
var User = require('../students/models/models.users');


const port = process.env.PORT || 3000;
var app = new express();
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());
var db = new mongoose();
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(require("express-session")({
    secret: "MySecret",
    resave: false,
    saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.listen(port);
console.log(`Server is Listening on ${process.env.PORT}`);

module.exports = app;